package com.shureck.recsys;

class Recommend {
    String name;
    String date;
    String discr;
    int photoId;

    Recommend(String name, String date, String discr, int photoId) {
        this.name = name;
        this.date = date;
        this.discr = discr;
        this.photoId = photoId;
    }
}