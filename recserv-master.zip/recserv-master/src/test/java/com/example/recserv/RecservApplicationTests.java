package com.example.recserv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecservApplicationTests {

    @Test
    void contextLoads() {
    }

}
